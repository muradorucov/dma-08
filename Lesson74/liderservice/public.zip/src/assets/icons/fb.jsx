import React from 'react'

function FbIcon() {
  return (
    <svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M11.1643 17.4975V10.6675H13.4684L13.8109 7.99332H11.1643V6.28999C11.1643 5.51832 11.3793 4.98999 12.4868 4.98999H13.8901V2.60582C13.2073 2.53265 12.521 2.49732 11.8343 2.49999C9.79761 2.49999 8.39927 3.74332 8.39927 6.02582V7.98832H6.11011V10.6625H8.40427V17.4975H11.1643Z"
        fill="white"
      />
    </svg>
  )
}

export default FbIcon